# integration wrapper modules (uses prior provided modules)
