import tkinter as tk
from tkinter import ttk, messagebox
import subprocess, os
from pathlib import Path

CREATE_NEW_CONSOLE = 0x00000010

class ControlTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Control (LIVE / STOP)")
        self._build()

    def _build(self):
        r=0
        ttk.Label(self, text="Runner (.bat):").grid(row=r, column=0, sticky="e", padx=6, pady=6)
        self.var_bat = tk.StringVar(value="ELBOTTO_ALL_IN_ONE_v2_1.bat")
        ttk.Entry(self, textvariable=self.var_bat, width=50).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Button(self, text="Browse…", command=self._pick_bat, width=12).grid(row=r, column=2, padx=6); r+=1

        ttk.Button(self, text="▶ Start LIVE", command=self._start_live).grid(row=r, column=0, padx=6, pady=8, sticky="we")
        ttk.Button(self, text="■ Stop LIVE", command=self._stop_live).grid(row=r, column=1, padx=6, pady=8, sticky="we")
        ttk.Button(self, text="📝 Open LOG", command=self._open_log).grid(row=r, column=2, padx=6, pady=8, sticky="we"); r+=1
        ttk.Button(self, text="📂 Open results folder", command=self._open_results).grid(row=r, column=0, columnspan=3, padx=6, pady=8, sticky="we"); r+=1

        self.grid_columnconfigure(1, weight=1)

    def _pick_bat(self):
        from tkinter.filedialog import askopenfilename
        path = askopenfilename(filetypes=[("Batch files","*.bat")])
        if path:
            self.var_bat.set(path)

    def _start_live(self):
        bat = self.var_bat.get()
        if not Path(bat).exists():
            messagebox.showerror("Not found", f"Runner not found:\n{bat}")
            return
        try:
            subprocess.Popen(["cmd.exe","/c", bat, "live"], creationflags=CREATE_NEW_CONSOLE)
            messagebox.showinfo("LIVE", "LIVE stack started (recorder+replay+paper+Adapter+ [+GUI]).")
        except Exception as e:
            messagebox.showerror("Error", f"Could not start LIVE:\n{e}")

    def _stop_live(self):
        bat = self.var_bat.get()
        if not Path(bat).exists():
            messagebox.showerror("Not found", f"Runner not found:\n{bat}")
            return
        try:
            subprocess.Popen(["cmd.exe","/c", bat, "stop"], creationflags=CREATE_NEW_CONSOLE)
            messagebox.showinfo("STOP", "Requested stop; check console/log if all processes were killed.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not stop LIVE:\n{e}")

    def _open_log(self):
        log = Path("results")/"_allinone.log"
        try:
            if log.exists():
                os.startfile(str(log))
            else:
                messagebox.showwarning("No log", f"Log file not found:\n{log}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _open_results(self):
        try:
            os.startfile(str(Path("results")))
        except Exception as e:
            messagebox.showerror("Error", str(e))
