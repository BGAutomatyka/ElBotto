
Param(
    [string]$PythonVersion = "3.11"
)
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

try {
    $pyInfo = & py -$PythonVersion -V
    Write-Host "[INFO] Found Python via 'py':" $pyInfo
} catch {
    Write-Warning "Nie znaleziono Pythona $PythonVersion. Zainstaluj go i uruchom ponownie."
    exit 1
}

if (-not (Test-Path ".\.venv")) {
    Write-Host "[INFO] Tworzę .venv ..."
    & py -$PythonVersion -m venv .venv
}

$venvPy = Join-Path ".\.venv\Scripts" "python.exe"

Write-Host "[INFO] Aktualizuję pip/setuptools/wheel ..."
& $venvPy -m pip install --upgrade pip setuptools wheel

Write-Host "[INFO] Instaluję zależności ..."
& $venvPy -m pip install -e ".[dev]"

Write-Host "[DONE] Środowisko gotowe. Uruchom GUI: RUN_GUI.bat"
