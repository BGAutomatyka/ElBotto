
Param(
    [string]$PythonVersion = "3.11"
)
$ErrorActionPreference = "Stop"

Set-Location -Path $PSScriptRoot
Write-Host "[INFO] Repo path:" (Get-Location).Path

try {
    $pyInfo = & py -$PythonVersion -V
    Write-Host "[INFO] Found Python via 'py':" $pyInfo
} catch {
    Write-Warning "Nie znaleziono Pythona $PythonVersion przez 'py'. Zainstaluj Python 3.11 i uruchom ponownie."
    exit 1
}

if (-not (Test-Path ".\.venv")) {
    Write-Host "[INFO] Tworzę wirtualne środowisko .venv ..."
    & py -$PythonVersion -m venv .venv
}

$venvPy = Join-Path ".\.venv\Scripts" "python.exe"

Write-Host "[INFO] Aktualizuję pip/setuptools/wheel ..."
& $venvPy -m pip install --upgrade pip setuptools wheel

Write-Host "[INFO] Instaluję pakiet w trybie editable (wraz z dev) ..."
& $venvPy -m pip install -e ".[dev]"

Write-Host "[INFO] Uruchamiam GUI ..."
& $venvPy -m elbotto.gui.app
