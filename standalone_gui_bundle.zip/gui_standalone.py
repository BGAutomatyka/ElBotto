
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import os, json, threading, time, subprocess

try:
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    HAS_MPL = True
except Exception as e:
    HAS_MPL = False
    MPL_ERR = str(e)

CREATE_NEW_CONSOLE = 0x00000010

def _read_json(p: Path):
    try:
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def _write_json_atomic(p: Path, data: dict):
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(p)

class ControlTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Control (LIVE / STOP)")
        self.var_bat  = tk.StringVar(value="ELBOTTO_ALL_IN_ONE_v2_1.bat")
        self.var_json = tk.StringVar(value="results\\runtime_overrides.json")
        self.var_thr    = tk.DoubleVar(value=0.10)
        self.var_risk   = tk.DoubleVar(value=0.005)
        self.var_maxpos = tk.IntVar(value=1)
        self.var_auto   = tk.BooleanVar(value=True)
        self.lbl_current = tk.StringVar(value="threshold=?, risk=?, max_position=?")
        self._build_ui()
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _build_ui(self):
        r=0
        ttk.Label(self, text="Runner (.bat):").grid(row=r, column=0, sticky="e", padx=6, pady=6)
        ttk.Entry(self, textvariable=self.var_bat, width=44).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Button(self, text="Browse…", command=self._pick_bat, width=12).grid(row=r, column=2, padx=6); r+=1

        ttk.Label(self, text="Overrides JSON:").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_json, width=44).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Button(self, text="Open", command=self._open_json, width=12).grid(row=r, column=2, padx=6); r+=1

        ttk.Label(self, text="threshold").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Scale(self, from_=0.0, to=0.50, variable=self.var_thr, command=lambda v:self._maybe_apply()).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Spinbox(self, from_=0.0, to=0.5, increment=0.005, textvariable=self.var_thr, width=10, command=self._maybe_apply).grid(row=r, column=2, padx=6); r+=1

        ttk.Label(self, text="risk_per_trade").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Scale(self, from_=0.0, to=0.05, variable=self.var_risk, command=lambda v:self._maybe_apply()).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Spinbox(self, from_=0.0, to=0.05, increment=0.001, textvariable=self.var_risk, width=10, command=self._maybe_apply).grid(row=r, column=2, padx=6); r+=1

        ttk.Label(self, text="max_position").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Scale(self, from_=0, to=5, variable=self.var_maxpos, command=lambda v:self._maybe_apply()).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Spinbox(self, from_=0, to=5, increment=1, textvariable=self.var_maxpos, width=10, command=self._maybe_apply).grid(row=r, column=2, padx=6); r+= 1

        ttk.Checkbutton(self, text="Auto-apply every 1s", variable=self.var_auto).grid(row=r, column=0, padx=6, pady=8, sticky="w")
        ttk.Button(self, text="Apply now", command=self.apply_now).grid(row=r, column=1, padx=6, pady=8, sticky="we")
        ttk.Button(self, text="Reset (clear file)", command=self.reset_file).grid(row=r, column=2, padx=6, pady=8, sticky="we"); r += 1

        ttk.Button(self, text="▶ Start LIVE", command=self._start_live).grid(row=r, column=0, padx=6, pady=8, sticky="we")
        ttk.Button(self, text="■ Stop LIVE",  command=self._stop_live).grid(row=r, column=1, padx=6, pady=8, sticky="we")
        ttk.Button(self, text="📝 Open LOG",  command=self._open_log).grid(row=r, column=2, padx=6, pady=8, sticky="we"); r += 1

        ttk.Label(self, textvariable=self.lbl_current, foreground="#008").grid(row=r, column=0, columnspan=3, sticky="w", padx=6, pady=6); r += 1
        ttk.Button(self, text="📂 Open results folder", command=self._open_results).grid(row=r, column=0, columnspan=3, padx=6, pady=8, sticky="we")

        self.grid_columnconfigure(1, weight=1)

    def _pick_bat(self):
        p = filedialog.askopenfilename(filetypes=[("Batch files","*.bat")])
        if p: self.var_bat.set(p)

    def _open_json(self):
        p = Path(self.var_json.get())
        if p.exists(): os.startfile(str(p))
        else: messagebox.showwarning("Not found", f"File does not exist:\n{p}")

    def _open_log(self):
        p = Path("results")/"_allinone.log"
        if p.exists(): os.startfile(str(p))
        else: messagebox.showwarning("No log", f"Not found:\n{p}")

    def _open_results(self):
        try: os.startfile(str(Path("results")))
        except Exception as e: messagebox.showerror("Error", str(e))

    def _start_live(self):
        bat = self.var_bat.get()
        if not Path(bat).exists():
            messagebox.showerror("Not found", f"Runner not found:\n{bat}")
            return
        try:
            subprocess.Popen(["cmd.exe","/c", bat, "live"], creationflags=CREATE_NEW_CONSOLE)
            messagebox.showinfo("LIVE", "LIVE stack started.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not start LIVE:\n{e}")

    def _stop_live(self):
        bat = self.var_bat.get()
        if not Path(bat).exists():
            messagebox.showerror("Not found", f"Runner not found:\n{bat}")
            return
        try:
            subprocess.Popen(["cmd.exe","/c", bat, "stop"], creationflags=CREATE_NEW_CONSOLE)
            messagebox.showinfo("STOP", "Requested stop; check console/log.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not stop LIVE:\n{e}")

    def _maybe_apply(self):
        if self.var_auto.get():
            self.apply_now()

    def apply_now(self):
        p = Path(self.var_json.get())
        current = _read_json(p)
        desired = {
            "threshold": round(float(self.var_thr.get()), 6),
            "risk_per_trade": round(float(self.var_risk.get()), 6),
            "max_position": int(self.var_maxpos.get()),
        }
        if any(current.get(k) != v for k, v in desired.items()):
            current.update(desired)
            try: _write_json_atomic(p, current)
            except Exception as e: messagebox.showerror("Write error", str(e))
        self._update_label(current)

    def reset_file(self):
        p = Path(self.var_json.get())
        try:
            if p.exists(): p.unlink()
            self._update_label({})
            messagebox.showinfo("Reset", "runtime_overrides.json cleared.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _update_label(self, d: dict):
        txt = f"current → threshold={d.get('threshold','∅')}, risk={d.get('risk_per_trade','∅')}, max_position={d.get('max_position','∅')}"
        self.lbl_current.set(txt)

    def _loop(self):
        last = None
        while True:
            try:
                p = Path(self.var_json.get())
                d = _read_json(p)
                if d != last:
                    self.after(0, self._update_label, d)
                    last = d
                if self.var_auto.get():
                    desired = {
                        "threshold": round(float(self.var_thr.get()), 6),
                        "risk_per_trade": round(float(self.var_risk.get()), 6),
                        "max_position": int(self.var_maxpos.get()),
                    }
                    if any(d.get(k) != v for k, v in desired.items()):
                        _write_json_atomic(p, {**d, **desired})
                        last = None
            except Exception:
                pass
            time.sleep(1.0)

class MetricsTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Live Metrics")
        self.var_equity_csv = tk.StringVar(value="results\\equity_paper.csv")
        self.var_features_csv = tk.StringVar(value="results\\lob_features_live.csv")
        self._build()
        threading.Thread(target=self._loop, daemon=True).start()

    def _build(self):
        r=0
        ttk.Label(self, text="Equity CSV:").grid(row=r, column=0, sticky="e", padx=6, pady=6)
        ttk.Entry(self, textvariable=self.var_equity_csv, width=48).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Label(self, text="Features CSV:").grid(row=r, column=2, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_features_csv, width=48).grid(row=r, column=3, sticky="we", padx=6); r+=1

        if HAS_MPL:
            self.fig_eq = Figure(figsize=(6,2.2)); self.ax_eq = self.fig_eq.add_subplot(111)
            self.fig_pos = Figure(figsize=(6,2.2)); self.ax_pos = self.fig_pos.add_subplot(111)
            self.fig_sig = Figure(figsize=(6,2.2)); self.ax_sig = self.fig_sig.add_subplot(111)
            self.canvas_eq = FigureCanvasTkAgg(self.fig_eq, master=self); self.canvas_eq.get_tk_widget().grid(row=r, column=0, columnspan=4, sticky="nsew", padx=6, pady=6); r+=1
            self.canvas_pos = FigureCanvasTkAgg(self.fig_pos, master=self); self.canvas_pos.get_tk_widget().grid(row=r, column=0, columnspan=4, sticky="nsew", padx=6, pady=6); r+=1
            self.canvas_sig = FigureCanvasTkAgg(self.fig_sig, master=self); self.canvas_sig.get_tk_widget().grid(row=r, column=0, columnspan=4, sticky="nsew", padx=6, pady=6); r+=1
            self.grid_rowconfigure(r-1, weight=1)
        else:
            ttk.Label(self, text=f"Matplotlib not available: {MPL_ERR}").grid(row=r, column=0, columnspan=4, sticky="we", padx=6, pady=6)

        self.grid_columnconfigure(1, weight=1); self.grid_columnconfigure(3, weight=1)

    def _loop(self):
        import pandas as pd
        while True:
            try:
                eqp = Path(self.var_equity_csv.get())
                if eqp.exists():
                    df = pd.read_csv(eqp)
                    if not df.empty and HAS_MPL:
                        self.ax_eq.clear(); self.ax_eq.plot(df["equity"].values); self.ax_eq.set_title("Equity"); self.ax_eq.grid(True); self.canvas_eq.draw()
                        self.ax_pos.clear(); self.ax_pos.plot(df["pos"].values); self.ax_pos.set_title("Position"); self.ax_pos.grid(True); self.canvas_pos.draw()
                fcp = Path(self.var_features_csv.get())
                if fcp.exists() and HAS_MPL:
                    df2 = pd.read_csv(fcp)
                    if not df2.empty:
                        n = min(1000, len(df2))
                        col = "microprice_imb" if "microprice_imb" in df2.columns else df2.columns[-1]
                        sig = df2[col].values[-n:]
                        self.ax_sig.clear(); self.ax_sig.plot(sig); self.ax_sig.set_title(f"Signal ({col})"); self.ax_sig.grid(True); self.canvas_sig.draw()
            except Exception:
                pass
            time.sleep(1.0)

class App(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.nb.add(ControlTab(self.nb), text="Control")
        self.nb.add(MetricsTab(self.nb), text="Metrics")

def main():
    root = tk.Tk()
    root.title("ElBotto - GUI (Standalone)")
    root.geometry("1100x700")
    try:
        style = ttk.Style()
        style.theme_use("clam")
    except Exception:
        pass
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
