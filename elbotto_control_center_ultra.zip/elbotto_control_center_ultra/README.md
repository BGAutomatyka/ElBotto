# ElBotto – Control Center (ULTRA)

**Najbardziej wypasione GUI** do Twojego bota. Nowości vs PLUS:
- *Trades & Equity:* parser transakcji z logu, **eksport CSV**, **equity curve**.
- *Charts:* wykres **equity** i **ΔPnL features** (matplotlib).
- *Param Grid (2D/3D):* siatka po `threshold × spread-max × windows-set`, zapis wyników i **Apply Best**.
- *Data Validator:* szybka walidacja kolumn CSV.
- *AutoLab:* po analizie sugeruje nowy `threshold` na bazie wpływów cech.
- *Regimes:* szybkie klastrowanie (KMeans) na CSV z cechami — detekcja reżimów rynku.
- *Indicators window:* wybór wskaźników, zapisy do JSON, opcjonalne dołączanie `--indicators ...` do procesu.
- *Data Sweep:* folder + pattern + chunking wielkich plików.

## Instalacja
1. Rozpakuj paczkę do **głównego katalogu projektu** (gdzie `.venv/`, `src/`, `data/`).
2. Uruchom `run_gui.bat` (korzysta z `.venv\Scripts\python.exe`).

## Wymagane/ Opcjonalne pakiety
- Wymagane: `tkinter` (Windows wbudowany).
- Opcjonalne: `pandas`, `scikit-learn`, `matplotlib`, `xgboost` (dla Model/Regime/Charts).

## Co przygotować w logach
Parser wspiera linie typu:
```
TRADE: time=2024-07-01T12:05:00Z, symbol=BTCUSDT, side=BUY, qty=0.01, price=65000.5, pnl=12.34
```
albo luźniejsze:
```
Trade BTCUSDT BUY qty=0.01 @ 65000.5 ... pnl=12.34
```
oraz bloki:
```
=== BTCUSDT ===
Transakcji: 12, końcowy kapitał: 5234.56
```

## Tipy
- Jeśli Twoje skrypty nie przyjmują `--indicators`: odznacz checkbox; GUI i tak zapisze wybór do `results/selected_indicators.json`.
- `Param Grid` zapisze zestawienie do `results/grid_results_*.csv` i podpowie *best config* również w `best_config.json`.

Miłej jazdy 🚀
