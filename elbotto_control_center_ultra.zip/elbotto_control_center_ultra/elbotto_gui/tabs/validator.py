import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import csv
from pathlib import Path

class ValidatorTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Data Validator")
        self.var_file = tk.StringVar(value="")
        self.var_required = tk.StringVar(value="timestamp,price,volume")  # adjust as needed

        r=0
        ttk.Label(self, text="CSV file:").grid(row=r, column=0, sticky="e", padx=6, pady=6)
        ttk.Entry(self, textvariable=self.var_file, width=60).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Button(self, text="Browse…", command=self._pick).grid(row=r, column=2, padx=6)
        r+=1
        ttk.Label(self, text="Required columns (comma-separated):").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_required, width=60).grid(row=r, column=1, sticky="we", padx=6)

    def _pick(self):
        p = filedialog.askopenfilename(title="Select CSV", filetypes=[("CSV","*.csv"),("All","*.*")])
        if p: self.var_file.set(p)

    def validate(self):
        path = Path(self.var_file.get())
        if not path.exists():
            messagebox.showwarning("Validator", "File not found."); return False, "not found"
        required = [c.strip() for c in self.var_required.get().split(",") if c.strip()]
        try:
            import pandas as pd
            df = pd.read_csv(path, nrows=1000)  # sample
            missing = [c for c in required if c not in df.columns]
            return True, {"missing": missing, "rows_sampled": len(df), "columns": list(df.columns)}
        except Exception:
            # fallback to CSV reader
            with path.open("r", encoding="utf-8") as f:
                header = f.readline().strip().split(",")
            missing = [c for c in required if c not in header]
            return True, {"missing": missing, "rows_sampled": "N/A", "columns": header}
