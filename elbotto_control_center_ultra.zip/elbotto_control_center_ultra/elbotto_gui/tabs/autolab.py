import tkinter as tk
from tkinter import ttk

class AutoLabTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="AutoLab (Train → Model Lab → Apply)")
        self.var_enable = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Enable Auto pipeline after Analysis", variable=self.var_enable).pack(anchor="w", padx=6, pady=6)
        ttk.Label(self, text="Po analizie: spróbuje wytrenować szybki model na 'metrics_latest_features.csv' i zasugerować nowy threshold.").pack(anchor="w", padx=6, pady=6)
