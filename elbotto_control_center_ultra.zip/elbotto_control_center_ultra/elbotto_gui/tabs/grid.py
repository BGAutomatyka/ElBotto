import tkinter as tk
from tkinter import ttk
import os

class GridTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Parameter Grid (2D/3D)")
        self.var_thresholds = tk.StringVar(value="0.35 0.40 0.45 0.50 0.55 0.60")
        self.var_spreads    = tk.StringVar(value="")
        self.var_windows    = tk.StringVar(value="3 6 9|5 10 20")  # pipe-separated sets
        self.var_metric     = tk.StringVar(value="sum_capital")

        r=0
        ttk.Label(self, text="Thresholds:").grid(row=r, column=0, sticky="e", padx=6, pady=6)
        ttk.Entry(self, textvariable=self.var_thresholds, width=40).grid(row=r, column=1, sticky="w", padx=6)
        r+=1
        ttk.Label(self, text="Spread-max list (optional):").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_spreads, width=40).grid(row=r, column=1, sticky="w", padx=6)
        r+=1
        ttk.Label(self, text="Windows sets (pipe-separated):").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_windows, width=40).grid(row=r, column=1, sticky="w", padx=6)
        r+=1
        ttk.Label(self, text="Metric for best:").grid(row=r, column=0, sticky="e", padx=6)
        ttk.Combobox(self, textvariable=self.var_metric, values=["sum_capital","btc_cap","eth_cap","trades_total"], state="readonly", width=20).grid(row=r, column=1, sticky="w", padx=6)
