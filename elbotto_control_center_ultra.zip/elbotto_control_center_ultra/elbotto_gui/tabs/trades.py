import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

class TradesTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Trades & Equity")
        self.var_export = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Auto-export trades/equity CSV", variable=self.var_export).pack(anchor="w", padx=8, pady=6)
        self.var_info = tk.StringVar(value="Po runie panel spróbuje sparsować transakcje z logu.")
        ttk.Label(self, textvariable=self.var_info).pack(anchor="w", padx=8, pady=6)
