import tkinter as tk
from tkinter import ttk, filedialog, messagebox

class RegimesTab(ttk.LabelFrame):
    def __init__(self, master):
        super().__init__(master, text="Regime Lab (unsupervised)")
        self.var_csv = tk.StringVar(value="results\metrics_latest_features.csv")
        self.var_k   = tk.IntVar(value=3)
        ttk.Label(self, text="Features CSV:").grid(row=0, column=0, sticky="e", padx=6, pady=6)
        ttk.Entry(self, textvariable=self.var_csv, width=60).grid(row=0, column=1, sticky="we", padx=6)
        ttk.Button(self, text="Browse…", command=self._pick).grid(row=0, column=2, padx=6)
        ttk.Label(self, text="K clusters:").grid(row=1, column=0, sticky="e", padx=6)
        ttk.Entry(self, textvariable=self.var_k, width=6).grid(row=1, column=1, sticky="w", padx=6)

    def _pick(self):
        p = filedialog.askopenfilename(title="Select CSV", filetypes=[("CSV","*.csv"),("All","*.*")])
        if p: self.var_csv.set(p)
