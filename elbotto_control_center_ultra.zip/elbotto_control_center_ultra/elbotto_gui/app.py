import os, csv, datetime, json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .storage import RESULTS_DIR, DEFAULTS, load_params, save_params, load_profiles, save_profiles, load_indicators, save_indicators, save_best, load_best
from .runner import ProcessRunner
from .parsing import parse_incremental, parse_full, compute_equity
from .exporters import export_trades_csv, export_equity_csv

from .widgets.metrics import MetricsPanel
from .widgets.indicator_window import IndicatorWindow
from .tabs.analysis import AnalysisTab
from .tabs.backtest import BacktestTab
from .tabs.sweep import SweepTab
from .tabs.data_sweep import DataSweepTab
from .tabs.training import TrainingTab
from .tabs.live import LiveTab
from .tabs.charts import ChartsTab
from .tabs.trades import TradesTab
from .tabs.grid import GridTab
from .tabs.validator import ValidatorTab
from .tabs.autolab import AutoLabTab
from .tabs.regimes import RegimesTab

class ControlCenter(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=8)
        self.master = master
        self.pack(fill="both", expand=True)
        self.proc = ProcessRunner(RESULTS_DIR)
        self.accum = {}
        self.current_feats = []
        self.trades = []
        self.equity_times = []; self.equity_vals = []

        self._build_ui()
        self._load_params()

    def _build_ui(self):
        self.master.title("ElBotto – Control Center (ULTRA)")
        self.master.geometry("1360x880")

        # Common params
        self.frm = ttk.LabelFrame(self, text="Common Parameters")
        self.frm.pack(fill="x")
        self.var_dataset   = tk.StringVar(value=DEFAULTS["dataset"])
        self.var_symbols   = tk.StringVar(value=DEFAULTS["symbols"])
        self.var_threshold = tk.DoubleVar(value=DEFAULTS["threshold"])
        self.var_capital   = tk.DoubleVar(value=DEFAULTS["capital"])
        self.var_maxpos    = tk.DoubleVar(value=DEFAULTS["max_position"])
        self.var_fee       = tk.DoubleVar(value=DEFAULTS["fee"])
        self.var_windows   = tk.StringVar(value=DEFAULTS["windows"])
        self.var_spread    = tk.StringVar(value=DEFAULTS["spread_max"])
        self.var_tp        = tk.StringVar(value=DEFAULTS["tp_bps"])
        self.var_sl        = tk.StringVar(value=DEFAULTS["sl_bps"])
        self.var_risk      = tk.StringVar(value=DEFAULTS["risk_per_trade"])
        self.var_extra     = tk.StringVar(value=DEFAULTS.get("extra_args",""))
        self.var_append_ind= tk.BooleanVar(value=DEFAULTS.get("append_indicators_flag", False))
        self.var_required  = tk.StringVar(value=DEFAULTS.get("required_columns","timestamp,price,volume"))

        r=0
        ttk.Label(self.frm, text="Dataset:").grid(row=r, column=0, sticky="w", padx=6, pady=4)
        ttk.Entry(self.frm, textvariable=self.var_dataset, width=70).grid(row=r, column=1, sticky="we", padx=6)
        ttk.Button(self.frm, text="Browse…", command=self._pick_dataset).grid(row=r, column=2, padx=6)
        r+=1
        ttk.Label(self.frm, text="Symbols:").grid(row=r, column=0, sticky="w", padx=6, pady=4)
        ttk.Entry(self.frm, textvariable=self.var_symbols, width=40).grid(row=r, column=1, sticky="w", padx=6)
        ttk.Label(self.frm, text="Windows:").grid(row=r, column=2, sticky="e")
        ttk.Entry(self.frm, textvariable=self.var_windows, width=18).grid(row=r, column=3, sticky="w", padx=6)
        r+=1
        ttk.Label(self.frm, text="Threshold:").grid(row=r, column=0, sticky="w", padx=6)
        ttk.Entry(self.frm, textvariable=self.var_threshold, width=10).grid(row=r, column=1, sticky="w")
        ttk.Label(self.frm, text="Capital:").grid(row=r, column=2, sticky="e")
        ttk.Entry(self.frm, textvariable=self.var_capital, width=12).grid(row=r, column=3, sticky="w", padx=6)
        r+=1
        ttk.Label(self.frm, text="Max pos:").grid(row=r, column=0, sticky="w", padx=6)
        ttk.Entry(self.frm, textvariable=self.var_maxpos, width=10).grid(row=r, column=1, sticky="w")
        ttk.Label(self.frm, text="Fee:").grid(row=r, column=2, sticky="e")
        ttk.Entry(self.frm, textvariable=self.var_fee, width=10).grid(row=r, column=3, sticky="w", padx=6)
        r+=1
        ttk.Label(self.frm, text="Spread max:").grid(row=r, column=0, sticky="w", padx=6)
        ttk.Entry(self.frm, textvariable=self.var_spread, width=10).grid(row=r, column=1, sticky="w")
        ttk.Label(self.frm, text="TP/SL (bps):").grid(row=r, column=2, sticky="e")
        fr = ttk.Frame(self.frm); fr.grid(row=r, column=3, sticky="w")
        ttk.Entry(fr, textvariable=self.var_tp, width=7).pack(side="left")
        ttk.Label(fr, text="/").pack(side="left", padx=4)
        ttk.Entry(fr, textvariable=self.var_sl, width=7).pack(side="left")
        r+=1
        ttk.Label(self.frm, text="Risk per trade:").grid(row=r, column=0, sticky="w", padx=6)
        ttk.Entry(self.frm, textvariable=self.var_risk, width=10).grid(row=r, column=1, sticky="w")
        ttk.Label(self.frm, text="Extra args:").grid(row=r, column=2, sticky="e")
        ttk.Entry(self.frm, textvariable=self.var_extra, width=30).grid(row=r, column=3, sticky="w", padx=6)
        r+=1
        ttk.Label(self.frm, text="Required columns:").grid(row=r, column=0, sticky="w", padx=6)
        ttk.Entry(self.frm, textvariable=self.var_required, width=30).grid(row=r, column=1, sticky="w", padx=6)

        tools = ttk.Frame(self); tools.pack(fill="x", pady=6)
        ttk.Button(tools, text="Indicators…", command=self._open_indicators).pack(side="left", padx=4)
        ttk.Checkbutton(tools, text="Append selected indicators to args", variable=self.var_append_ind).pack(side="left", padx=4)
        ttk.Button(tools, text="Open Results", command=self._open_results).pack(side="right", padx=4)

        # Tabs
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.var_analysis_script = tk.StringVar()
        self.var_backtest_script = tk.StringVar()
        self.var_train_script = tk.StringVar()
        self.var_paper_script = tk.StringVar()
        self.var_live_script = tk.StringVar()
        self.var_env = tk.StringVar(value="paper")
        self.var_api_key = tk.StringVar()
        self.var_api_secret = tk.StringVar()

        self.tab_analysis = AnalysisTab(self.nb, self.var_analysis_script); self.nb.add(self.tab_analysis, text="Analysis")
        self.tab_backtest = BacktestTab(self.nb, self.var_backtest_script); self.nb.add(self.tab_backtest, text="Backtest")
        self.tab_sweep = SweepTab(self.nb); self.nb.add(self.tab_sweep, text="Batch Sweep")
        self.tab_data_sweep = DataSweepTab(self.nb); self.nb.add(self.tab_data_sweep, text="Data Sweep")
        self.tab_train = TrainingTab(self.nb, self.var_train_script); self.nb.add(self.tab_train, text="Training")
        self.tab_live = LiveTab(self.nb, self.var_paper_script, self.var_live_script, self.var_env, self.var_api_key, self.var_api_secret); self.nb.add(self.tab_live, text="Paper/Live")
        self.tab_charts = ChartsTab(self.nb); self.nb.add(self.tab_charts, text="Charts")
        self.tab_trades = TradesTab(self.nb); self.nb.add(self.tab_trades, text="Trades/Equity")
        self.tab_grid = GridTab(self.nb); self.nb.add(self.tab_grid, text="Param Grid")
        self.tab_validator = ValidatorTab(self.nb); self.nb.add(self.tab_validator, text="Validator")
        self.tab_autolab = AutoLabTab(self.nb); self.nb.add(self.tab_autolab, text="AutoLab")
        self.tab_regimes = RegimesTab(self.nb); self.nb.add(self.tab_regimes, text="Regimes")

        # Output & metrics
        split = ttk.PanedWindow(self, orient="vertical"); split.pack(fill="both", expand=True, pady=(6,0))
        self.metrics = MetricsPanel(split)
        logf = ttk.LabelFrame(split, text="Log")
        self.txt = tk.Text(logf, wrap="word"); self.txt.pack(fill="both", expand=True, padx=6, pady=6)
        split.add(self.metrics, weight=1); split.add(logf, weight=2)

        # Bottom
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        self.btn_run = ttk.Button(bar, text="▶ Run", command=self._run_clicked); self.btn_run.pack(side="left", padx=6)
        self.btn_stop = ttk.Button(bar, text="■ Stop", command=self._stop_clicked, state="disabled"); self.btn_stop.pack(side="left", padx=6)
        self.status = ttk.Label(bar, text="Ready"); self.status.pack(side="right", padx=6)

        self.after(100, self._tick)

    # Utils
    def _pick_dataset(self):
        p = filedialog.askopenfilename(title="Select CSV", filetypes=[("CSV","*.csv"),("All","*.*")])
        if p: self.var_dataset.set(p)

    def _open_indicators(self):
        def on_change(selected, append_flag):
            self.current_indicators = selected; self.var_append_ind.set(bool(append_flag))
            save_indicators(selected)
        IndicatorWindow(self.master, on_change=on_change)

    def _collect(self):
        return {
            "dataset": self.var_dataset.get(),
            "symbols": self.var_symbols.get(),
            "threshold": float(self.var_threshold.get()),
            "capital": float(self.var_capital.get()),
            "max_position": float(self.var_maxpos.get()),
            "fee": float(self.var_fee.get()),
            "windows": self.var_windows.get(),
            "spread_max": self.var_spread.get(),
            "tp_bps": self.var_tp.get(),
            "sl_bps": self.var_sl.get(),
            "risk_per_trade": self.var_risk.get(),
            "analysis_script": self.var_analysis_script.get() or "run_quickstart_tuned.py",
            "backtest_script": self.var_backtest_script.get() or "src\elbotto\backtest\backtest.py",
            "train_script": self.var_train_script.get() or "src\elbotto\ml\train.py",
            "paper_script": self.var_paper_script.get() or "src\elbotto\bots\paper.py",
            "live_script": self.var_live_script.get() or "src\elbotto\bots\live.py",
            "env": self.var_env.get(),
            "api_key": self.var_api_key.get(),
            "api_secret": self.var_api_secret.get(),
            "extra_args": self.var_extra.get(),
            "append_indicators_flag": self.var_append_ind.get(),
            "required_columns": self.var_required.get()
        }

    def _load_params(self):
        cfg = load_params()
        self.var_dataset.set(cfg.get("dataset")); self.var_symbols.set(cfg.get("symbols"))
        self.var_threshold.set(cfg.get("threshold",0.5)); self.var_capital.set(cfg.get("capital",5000.0))
        self.var_maxpos.set(cfg.get("max_position",1.0)); self.var_fee.set(cfg.get("fee",0.0002))
        self.var_windows.set(cfg.get("windows","3 6 9")); self.var_spread.set(cfg.get("spread_max",""))
        self.var_tp.set(cfg.get("tp_bps","")); self.var_sl.set(cfg.get("sl_bps","")); self.var_risk.set(cfg.get("risk_per_trade",""))
        self.var_analysis_script.set(cfg.get("analysis_script","run_quickstart_tuned.py"))
        self.var_backtest_script.set(cfg.get("backtest_script","src\elbotto\backtest\backtest.py"))
        self.var_train_script.set(cfg.get("train_script","src\elbotto\ml\train.py"))
        self.var_paper_script.set(cfg.get("paper_script","src\elbotto\bots\paper.py"))
        self.var_live_script.set(cfg.get("live_script","src\elbotto\bots\live.py"))
        self.var_env.set(cfg.get("env","paper")); self.var_api_key.set(cfg.get("api_key","")); self.var_api_secret.set(cfg.get("api_secret",""))
        self.var_extra.set(cfg.get("extra_args","")); self.var_append_ind.set(cfg.get("append_indicators_flag", False))
        self.var_required.set(cfg.get("required_columns","timestamp,price,volume"))
        self.current_indicators = load_indicators()

    def _save_params(self):
        save_params(self._collect())

    def _open_results(self):
        RESULTS_DIR.mkdir(exist_ok=True)
        try: os.startfile(RESULTS_DIR)
        except Exception: messagebox.showinfo("Results", str(RESULTS_DIR.resolve()))

    def _append(self, s): self.txt.insert("end", s); self.txt.see("end")

    def _build_args(self, script):
        args = [Path(".venv")/"Scripts"/"python.exe", script,
                "--dataset", self.var_dataset.get(),
                "--threshold", str(self.var_threshold.get()),
                "--capital", str(self.var_capital.get()),
                "--max-position", str(self.var_maxpos.get()),
                "--fee", str(self.var_fee.get()),
                "--windows", *self.var_windows.get().split()]
        if self.var_symbols.get().strip(): args += ["--symbols", *self.var_symbols.get().split()]
        if self.var_spread.get(): args += ["--spread-max", str(self.var_spread.get())]
        if self.var_tp.get(): args += ["--take-profit-bps", str(self.var_tp.get())]
        if self.var_sl.get(): args += ["--stop-loss-bps", str(self.var_sl.get())]
        if self.var_risk.get(): args += ["--risk-per-trade", str(self.var_risk.get())]
        if self.var_append_ind.get() and getattr(self,'current_indicators',None): args += ["--indicators", *self.current_indicators]
        if self.var_extra.get().strip(): args += self.var_extra.get().split()
        return args

    def _run_clicked(self):
        if self.proc.proc and self.proc.proc.poll() is None:
            messagebox.showwarning("Busy", "Process already running."); return

        self.txt.delete("1.0","end"); self.accum = {}; self.current_feats = []; self.trades = []; self.equity_times=[]; self.equity_vals=[]
        self.btn_run.config(state="disabled"); self.btn_stop.config(state="normal"); self.status.config(text="Running…")

        tab = self.nb.tab(self.nb.select(), "text")
        if tab == "Analysis":
            args = self._build_args(self.var_analysis_script.get() or "run_quickstart_tuned.py")
            self.proc.start(args, self._on_line, os.environ.copy())
        elif tab == "Backtest":
            args = self._build_args(self.var_backtest_script.get())
            self.proc.start(args, self._on_line, os.environ.copy())
        elif tab == "Batch Sweep":
            start = float(self.tab_sweep.var_start.get()); stop = float(self.tab_sweep.var_stop.get()); step = float(self.tab_sweep.var_step.get())
            thresholds = [round(start + i*step, 10) for i in range(int((stop-start)/step)+1)]
            base = self._build_args(self.var_analysis_script.get() or "run_quickstart_tuned.py")
            def run_sweep():
                best = None
                for t in thresholds:
                    args = list(base)
                    for i, tok in enumerate(args):
                        if tok == "--threshold": args[i+1] = str(t); break
                    self._append(f"\n>> threshold={t}\n")
                    self.proc.start(args, self._on_line, os.environ.copy())
                    while True:
                        if self.proc.proc and self.proc.proc.poll() is not None: break
                        self.master.after(100, self.master.update())
                    # after each run, try to read capital metrics
                    m = getattr(self, "_last_metrics", {})
                    score = float(m.get("BTCUSDT_cap",0)) + float(m.get("ETHUSDT_cap",0))
                    if best is None or score > best[0]: best = (score, t)
                if best:
                    save_best({"threshold": best[1], "score": best[0]})
                    self._append(f"\n[BEST] threshold={best[1]} score={best[0]}\n")
                self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Finished")
            self.after(10, run_sweep)
        elif tab == "Data Sweep":
            files = self.tab_data_sweep.iter_files()
            base = self._build_args(self.var_analysis_script.get() or "run_quickstart_tuned.py")
            def run_files():
                for f in files:
                    chunks = list(self.tab_data_sweep.make_chunks(f))
                    for c in chunks:
                        args = list(base)
                        for i, tok in enumerate(args):
                            if tok == "--dataset": args[i+1] = str(c); break
                        self._append(f"\n>> dataset={c}\n")
                        self.proc.start(args, self._on_line, os.environ.copy())
                        while True:
                            if self.proc.proc and self.proc.proc.poll() is not None: break
                            self.master.after(100, self.master.update())
                self._append("\n[DATA SWEEP DONE]\n"); self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Finished")
            self.after(10, run_files)
        elif tab == "Training":
            args = self._build_args(self.var_train_script.get()) + ["--epochs", str(self.tab_train.var_epochs.get()), "--lr", str(self.tab_train.var_lr.get()), "--val", str(self.tab_train.var_val.get())]
            self.proc.start(args, self._on_line, os.environ.copy())
        elif tab == "Paper/Live":
            script = self.var_paper_script.get() if self.var_env.get()=="paper" else self.var_live_script.get()
            args = self._build_args(script)
            env = os.environ.copy()
            if self.var_api_key.get(): env["BINANCE_API_KEY"] = self.var_api_key.get()
            if self.var_api_secret.get(): env["BINANCE_API_SECRET"] = self.var_api_secret.get()
            self.proc.start(args, self._on_line, env)
        elif tab == "Charts":
            from .tabs.charts import ChartsTab
            self.tab_charts.plot_equity(self.equity_times, self.equity_vals)
            self.tab_charts.plot_features(self.current_feats)
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")
        elif tab == "Trades/Equity":
            messagebox.showinfo("Trades", "Po runie dane zostaną wyeksportowane automatycznie, jeśli włączone.")
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")
        elif tab == "Param Grid":
            # 2D/3D grid: threshold x spread-max x windows-sets
            thr_list = [float(x) for x in self.tab_grid.var_thresholds.get().split() if x.strip()]
            sp_list = [s for s in self.tab_grid.var_spreads.get().split() if s.strip()]
            win_sets = [w.strip() for w in self.tab_grid.var_windows.get().split("|") if w.strip()]
            base_script = self.var_analysis_script.get() or "run_quickstart_tuned.py"
            base = self._build_args(base_script)
            results = []
            def run_grid():
                best = None
                for thr in thr_list:
                    for sp in (sp_list or [""]):
                        for wset in win_sets:
                            args = list(base)
                            # apply thr, spread, windows
                            for i,tok in enumerate(args):
                                if tok == "--threshold": args[i+1] = str(thr)
                                if tok == "--windows": 
                                    args = args[:i+1] + wset.split() + args[i+2:]
                                    break
                            if sp:
                                if "--spread-max" in args:
                                    i = args.index("--spread-max"); args[i+1] = sp
                                else:
                                    args += ["--spread-max", sp]
                            self._append(f"\n>> thr={thr} spread={sp or '-'} windows=[{wset}]\n")
                            self.proc.start(args, self._on_line, os.environ.copy())
                            while True:
                                if self.proc.proc and self.proc.proc.poll() is not None: break
                                self.master.after(100, self.master.update())
                            m = getattr(self, "_last_metrics", {})
                            score = float(m.get("BTCUSDT_cap",0)) + float(m.get("ETHUSDT_cap",0))
                            results.append((thr, sp or "", wset, score))
                            if best is None or score > best[0]: best = (score, thr, sp or "", wset)
                # save summary
                ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                out = RESULTS_DIR / f"grid_results_{ts}.csv"
                with out.open("w", newline="", encoding="utf-8") as f:
                    w = csv.writer(f); w.writerow(["threshold","spread_max","windows_set","score"])
                    for r in results: w.writerow(r)
                if best:
                    save_best({"threshold": best[1], "spread_max": best[2], "windows": best[3], "score": best[0]})
                    self._append(f"\n[BEST] thr={best[1]} spread={best[2]} windows=[{best[3]}] score={best[0]}\n")
                self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Finished")
            self.after(10, run_grid)
        elif tab == "Validator":
            ok, info = self.tab_validator.validate()
            if ok:
                self._append(f"[VALIDATOR] {info}\n")
            else:
                self._append("[VALIDATOR] failed\n")
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")
        elif tab == "AutoLab":
            # run quick model on metrics_latest_features.csv (if exists) to suggest threshold (toy example)
            path = RESULTS_DIR/"metrics_latest_features.csv"
            if not path.exists():
                messagebox.showinfo("AutoLab","Brak metrics_latest_features.csv – wykonaj Analysis najpierw."); 
                self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready"); return
            # For demonstration: compute simple weighted threshold suggestion based on positive ΔPnL
            try:
                import pandas as pd
                df = pd.read_csv(path)
                pos = df[df["delta"]>0]["delta"].sum()
                neg = -df[df["delta"]<0]["delta"].sum()
                ratio = pos/(pos+neg+1e-9)
                thr = round(0.35 + 0.4*ratio, 3)  # map ratio→[0.35,0.75]
                save_best({"threshold": thr, "from":"AutoLab"})
                self.var_threshold.set(thr)
                self._append(f"[AutoLab] Suggested threshold={thr} based on features.\n")
            except Exception as e:
                self._append(f"[AutoLab] failed: {e!r}\n")
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")
        elif tab == "Regimes":
            # optional clustering if sklearn available
            try:
                import pandas as pd
                from sklearn.cluster import KMeans
                path = self.tab_regimes.var_csv.get()
                df = pd.read_csv(path)
                feats = [c for c in df.columns if c not in ("feature","sign")]
                X = df[feats].select_dtypes(include=["float","int"]).fillna(0.0)
                k = int(self.tab_regimes.var_k.get())
                km = KMeans(n_clusters=k, n_init=10, random_state=42)
                labels = km.fit_predict(X)
                out = RESULTS_DIR / "regimes_labels.csv"
                X.assign(regime=labels).to_csv(out, index=False)
                self._append(f"[Regimes] Saved: {out}\n")
            except Exception as e:
                self._append(f"[Regimes] failed: {e!r}\n")
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")
        else:
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Ready")

    def _on_line(self, line: str):
        self._append(line)
        parse_incremental(line, self.accum)
        self.metrics.update_metrics(self.accum)
        feats = self.accum.get("features", [])
        if feats:
            self.current_feats = feats; self.metrics.set_features(feats)
        if "trades" in self.accum:
            self.trades = self.accum["trades"]
        if line.startswith("[EXIT]"):
            try:
                if self.proc.log_path and self.proc.log_path.exists():
                    text = self.proc.log_path.read_text(encoding="utf-8")
                    m, feats = parse_full(text); self._last_metrics = m
                    self.metrics.update_metrics(m)
                    if feats: self.current_feats = feats; self.metrics.set_features(feats)
                    # Trades/equity export
                    if self.trades:
                        times, eq = compute_equity(self.trades, starting_capital=float(self.var_capital.get()))
                        self.equity_times, self.equity_vals = times, eq
                        export_trades_csv(self.trades, RESULTS_DIR/"trades_latest.csv")
                        export_equity_csv(times, eq, RESULTS_DIR/"equity_latest.csv")
                        self._append("\n[INFO] Exported trades/equity CSV.\n")
                    # Save features for Model Lab
                    if feats:
                        (RESULTS_DIR/"metrics_latest_features.csv").write_text("feature,delta,sign\n" + "\n".join(f"{n},{val},{sg}" for n,val,sg in feats), encoding="utf-8")
            except Exception as e:
                self._append(f"[WARN] finalize failed: {e!r}\n")
            self.btn_run.config(state="normal"); self.btn_stop.config(state="disabled"); self.status.config(text="Finished")

    def _stop_clicked(self):
        self.proc.terminate()
        self.btn_stop.config(state="disabled"); self.btn_run.config(state="normal")

    def _tick(self):
        self.after(200, self._tick)

def main():
    root = tk.Tk()
    ControlCenter(root)
    root.mainloop()

if __name__ == "__main__":
    main()
