import re
from typing import List, Dict, Tuple
from datetime import datetime

TRADE_PATTERNS = [
    # Flexible patterns: adapt to your log format here
    re.compile(r"TRADE[: ]+time=(?P<time>[^,]+),\s*symbol=(?P<symbol>\w+),\s*side=(?P<side>BUY|SELL),\s*qty=(?P<qty>[0-9.]+),\s*price=(?P<price>[0-9.]+),\s*pnl=(?P<pnl>[-0-9.]+)", re.I),
    re.compile(r"Trade\s+(?P<symbol>\w+)\s+(?P<side>BUY|SELL)\s+qty=(?P<qty>[0-9.]+)\s+@\s+(?P<price>[0-9.]+).*?pnl=(?P<pnl>[-0-9.]+)", re.I),
]

def parse_incremental(line: str, accum: dict):
    # Features ΔPnL
    m = re.search(r"([+−\-])\s*([a-zA-Z0-9_]+):\s*ΔPnL\s*=\s*([\-0-9.]+)", line)
    if m:
        sign, name, val = m.group(1), m.group(2), float(m.group(3))
        feats = accum.setdefault("features", [])
        feats.append((name, val, sign))
        return
    # Symbol header
    m = re.search(r"===\s*([A-Z]+)\s*===", line)
    if m:
        accum["last_symbol"] = m.group(1)
        return
    # Trades/capital
    m = re.search(r"Transakcji:\s*(\d+),\s*końcowy kapitał:\s*([0-9.]+)", line)
    if m and accum.get("last_symbol"):
        sym = accum["last_symbol"]
        accum[f"{sym}_trades"] = int(m.group(1))
        accum[f"{sym}_cap"] = float(m.group(2))
        return
    # Trade lines
    for pat in TRADE_PATTERNS:
        tm = pat.search(line)
        if tm:
            tr = {
                "time": tm.groupdict().get("time", ""),
                "symbol": tm.group("symbol"),
                "side": tm.group("side").upper(),
                "qty": float(tm.group("qty")) if tm.groupdict().get("qty") else None,
                "price": float(tm.group("price")) if tm.groupdict().get("price") else None,
                "pnl": float(tm.group("pnl")) if tm.groupdict().get("pnl") else 0.0
            }
            trades = accum.setdefault("trades", [])
            trades.append(tr)
            return

def parse_full(text: str):
    acc = {}
    for ln in text.splitlines():
        parse_incremental(ln, acc)
    feats = acc.pop("features", [])
    return acc, feats

def compute_equity(trades: List[dict], starting_capital: float = 0.0):
    times, equity = [], []
    cap = starting_capital
    for t in trades:
        cap += float(t.get("pnl", 0.0))
        # Try to parse time
        ts = t.get("time", "")
        try:
            # flexible parse attempt
            dt = datetime.fromisoformat(ts.replace("Z","").replace(" ", "T"))
        except Exception:
            dt = None
        times.append(ts if ts else str(len(times)))
        equity.append(cap)
    return times, equity
